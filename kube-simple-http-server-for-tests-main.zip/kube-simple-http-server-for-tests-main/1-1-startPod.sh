kubectl apply -f ./simple/pod-namespace.yaml
sleep 2
kubectl apply -f simple
