kubectl apply -f ./simple-ingress-http/pod-namespace.yaml
sleep 2
kubectl apply -f simple-ingress-http
