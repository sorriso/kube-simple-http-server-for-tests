kubectl delete -f simple-ingress-http
