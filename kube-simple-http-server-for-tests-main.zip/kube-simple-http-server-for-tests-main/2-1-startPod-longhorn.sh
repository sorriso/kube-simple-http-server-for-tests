kubectl apply -f ./simple-longhorn/pod-namespace.yaml
sleep 2
kubectl apply -f simple-longhorn
