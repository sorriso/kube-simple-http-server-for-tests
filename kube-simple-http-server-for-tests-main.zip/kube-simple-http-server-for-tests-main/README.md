# kube-simple-http-server-for-tests


sso

https://docs.nginx.com/nginx/deployment-guides/single-sign-on/keycloak/
