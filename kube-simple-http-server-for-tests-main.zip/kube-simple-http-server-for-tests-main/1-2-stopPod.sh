kubectl delete -f simple
