kubectl delete -f simple-ingress-https-vault-sso

kubectl delete secret simple-nginx-sso-certificate -n simple-ingress-https-vault-sso
