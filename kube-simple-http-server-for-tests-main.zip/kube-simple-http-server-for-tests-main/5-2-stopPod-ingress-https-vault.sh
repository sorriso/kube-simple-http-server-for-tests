kubectl delete -f simple-ingress-https-vault

kubectl delete secret simple-nginx-certificate -n simple-ingress-https-vault
