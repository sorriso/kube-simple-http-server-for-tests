kubectl delete -f simple-longhorn
