kubectl delete -f simple-ingress-https

kubectl delete secret pod-test-ingress-secret
